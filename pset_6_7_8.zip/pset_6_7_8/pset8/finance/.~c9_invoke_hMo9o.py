import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash


from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    user_id = session["user_id"]

    index = 0
    rows = []

    # Query database
    userData = db.execute(
        "SELECT symbol, name, SUM(shares), price, SUM(price), SUM(total_purchase) FROM `transaction` WHERE user_id = :id GROUP BY symbol", id=user_id)

    totalPurchase = db.execute("SELECT SUM(total_purchase) FROM `transaction` WHERE user_id = :id", id=session["user_id"])
    totalPurchase = totalPurchase[0]["SUM(total_purchase)"]

    # query user's cash
    userCash = db.execute("SELECT cash FROM users WHERE id = :id", id=session["user_id"])
    userCash = userCash[0]["cash"]

    # make a list of dict from userData
    for entry in userData:
        row = dict(symbol=userData[index]["symbol"], name=userData[index]["name"], shares=userData[index]["SUM(shares)"],
                   price=usd(userData[index]["price"]), total=usd(userData[index]["SUM(total_purchase)"]))
        rows.append(row)
        index += 1

    if not totalPurchase:
        totalPurchase = 0

    sumPurchase = usd(totalPurchase + userCash)
    # totalPurchase = usd(totalPurchase)
    userCash = usd(userCash)

    # Redirect user to home page
    return render_template("index.html", rows=rows, userCash=userCash, sumPurchase=sumPurchase)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        symbol = request.form.get("symbol")
        shares = request.form.get("shares")

        # validate user input
        if not shares:
            return apology("empty shares")
        if not shares.isdigit():
            return apology("shares must be a number")
        if int(shares) < 1:
            return apology("shares must be greater than 0")
        if "." in shares:
            return apology("shares must be an int")

        data = lookup(symbol)

        # validate if symbol exists
        if not data:
            return apology("invalid symbol")

        shares = int(shares)

        # Query database for user's cash
        userCash = db.execute("SELECT cash FROM users WHERE id = :id", id=session["user_id"])

        userCash = userCash[0]["cash"]

        latestPrice = data["price"]
        name = data["name"]
        symbol = data["symbol"]
        purchase = shares * latestPrice
        session_id = session["user_id"]

        # SELECT returns a list of dict objects so;
        # [{'cash', 10000}]
        if purchase > userCash:
            return apology("Not enough funds")

        # if user can afford
        # insert to datase transaction
        db.execute("INSERT INTO `transaction`(user_id,symbol,name,shares,price,total_purchase) \
                    VALUES(:user_id, :symbol, :name, :shares, :price, :total_purchase)",
                   user_id=session_id, symbol=symbol, name=name, shares=shares, price=latestPrice,
                   total_purchase=purchase)
        # update user's cash
        db.execute("UPDATE users SET cash = :purchase WHERE id = :userid",
                   purchase=userCash-purchase, userid=session_id)

        userCash = usd(userCash-purchase)
        latestPrice = usd(latestPrice)
        purchase = usd(purchase)

        return render_template("bought.html", symbol=symbol, price=latestPrice, purchase=purchase, cash=userCash)
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("buy.html")


@app.route("/check", methods=["GET"])
def check():
    """Return true if username available, else false, in JSON format"""

    username = request.args.get("username")
    usernamedb = db.execute("SELECT username FROM users WHERE username = :username", username=username)
    if not usernamedb:
        return jsonify(True)

    usernamedb = usernamedb[0]["username"]

    # return false if username exists
    if len(username) > 0 and not username == usernamedb:
        print('true')
        return jsonify(True)
    return jsonify(False)


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""

    user_id = session["user_id"]

    index = 0
    rows = []

    # Query database
    userData = db.execute("SELECT symbol, shares, price, datetime FROM `transaction` WHERE user_id = :id", id=user_id)

    # make a list of dict from userData
    for entry in userData:
        row = dict(symbol=userData[index]["symbol"], shares=userData[index]["shares"],
                   price=usd(userData[index]["price"]), datetime=userData[index]["datetime"])
        rows.append(row)
        index += 1

    # Redirect user to history
    return render_template("history.html", rows=rows)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username")

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password")

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password")

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    if request.method == "POST":
        symbol = request.form.get("symbol")
        data = lookup(symbol)

        # check if field is not empty
        if not symbol:
            return apology("Missing symbol!")
        elif not data:
            return apology("Invalid symbol!")
        else:
            # store data from lookup
            price = usd(data["price"])
            name = data["name"]
            # show quoted page
            return render_template("quoted.html", price=price, name=name, symbol=symbol)
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # check if username and password is not empty
        if not request.form.get("username"):
            return apology("Missing username!")
        elif not request.form.get("password"):
            return apology("Missing password!")
        # validate password
        elif request.form.get("password") != request.form.get("confirmation"):
            return apology("Passwords don't match")

        # check for duplicate username
        usernameinput = request.form.get("username")
        usernamedbinput = db.execute("SELECT username FROM users WHERE username = :username", username=usernameinput)

        # usernamedbinput = usernamedbinput[0]["username"]
        if usernamedbinput:
            return apology("username already exists")

        # insert to database username and password
        hash = generate_password_hash(request.form.get("password"))

        db.execute("INSERT INTO users(username,hash) VALUES(:username, :hash)",
                   username=request.form.get("username"), hash=hash)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password")

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    # Remember which user has logged in
    user_id = session["user_id"]

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # check if shares and symbol are not empty
        if not request.form.get("shares"):
            return apology("Missing shares!")
        elif not request.form.get("symbol"):
            return apology("Missing symbol!")

        sell_shares = int(request.form.get("shares"))
        sell_symbol = request.form.get("symbol")
        data = lookup(sell_symbol)

        price = float(data["price"])
        name = data["name"]
        sell = sell_shares * price

        # Query database for shares
        index = 0
        rows = []

        userShares = db.execute(
            "SELECT symbol, SUM(shares) FROM `transaction` WHERE user_id = :id GROUP BY symbol = :symbol", id=user_id, symbol=sell_symbol)

        # make a list of dict from userShares
        for symbols in userShares:
            row = dict(symbol=userShares[index]["symbol"], shares=userShares[index]["SUM(shares)"])
            rows.append(row)
            index += 1

        for row in rows:
            if row["symbol"] == sell_symbol:
                userShares = row["shares"]

        # check if user has enough shares to sell
        if userShares < sell_shares:
            return apology("Not enough shares!")

        # if user has enough shares
        # insert to datase transaction
        db.execute("INSERT INTO `transaction`(user_id,symbol,name,shares,price,total_purchase) \
                    VALUES(:user_id, :symbol, :name, :shares, :price, :total_purchase)",
                   user_id=user_id, symbol=sell_symbol, name=name, shares=-sell_shares, price=price, total_purchase=-sell)

        # update user's cash
        # query user's cash
        userCash = db.execute("SELECT cash FROM users WHERE id = :id", id=user_id)
        userCash = userCash[0]["cash"]

        db.execute("UPDATE users SET cash = :purchase WHERE id = :userid",
                   purchase=userCash+sell, userid=user_id)

        # Redirect user to home page
        return redirect("/")
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        index = 0
        rows = []
        # Query database
        userData = db.execute("SELECT symbol, SUM(shares) FROM `transaction` WHERE user_id = :id GROUP BY symbol", id=user_id)
        # make a list of dict from userData
        for entry in userData:
            row = dict(symbol=userData[index]["symbol"], shares=userData[index]["SUM(shares)"])
            rows.append(row)
            index += 1
        return render_template("sell.html", rows=rows)


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
