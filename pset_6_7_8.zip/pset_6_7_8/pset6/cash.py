from cs50 import get_float


def main():
    # ask for change owed
    change = get_change()

    # conver change to cents
    changeInCent = change * 100

    # greedy algorithm
    while changeInCent > 0:
        # quarter
        quarter = changeInCent//25
        changeInCent = changeInCent % 25
        # dime
        dime = changeInCent//10
        changeInCent = changeInCent % 10
        # nickel
        nickel = changeInCent//5
        changeInCent = changeInCent % 5
        # pennie
        pennie = changeInCent//1
        changeInCent = changeInCent % 1

    coins = quarter + dime + nickel + pennie

    # print coins used
    print(int(coins))

# validate user input


def get_change():
    while True:
        c = get_float("Change owed: ")
        if c >= 0:
            return c


if __name__ == "__main__":
    main()