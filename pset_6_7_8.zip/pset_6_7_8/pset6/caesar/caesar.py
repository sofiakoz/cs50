# import modules
from cs50 import get_string
from sys import argv
import sys


def main():
    # TODO
    # correct usage
    if len(argv) != 2:
        sys.exit("Usage: python caesar.py k")

    # get the key
    key = int(argv[1])
    key = key % 26
    # get the plaintext
    plaintext = get_string("plaintext: ")
    # print ciphertext
    print("ciphertext: ", end="")
    # encipher
    encipher(plaintext, key)
    print()


def encipher(text, k):
    # c = (p+k)%26
    for char in text:
        if char.isalpha():
            if char.isupper():
                c = ((ord(char) - 65) + k) % 26
                c = chr(c + 65)
                print(c, end="")

            if char.islower():
                c = ((ord(char) - 97) + k) % 26
                c = chr(c + 97)
                print(c, end="")
        else:
            print(char, end="")


if __name__ == "__main__":
    main()