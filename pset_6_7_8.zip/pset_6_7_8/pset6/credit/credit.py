from cs50 import get_int
import sys


def main():
    # prompt for user input
    creditnum = get_creditnum()

    checksum(creditnum)
    print(companycheck(creditnum))


def get_creditnum():
    while True:
        num = get_int("Number: ")
        if num > 0:
            return num


def checksum(ccnum):
    # luhn's algotithm
    # multiply every other digit
    digits = 0
    digit1 = 0

    while ccnum > 0:
        digit1 = digit1 + ccnum % 10
        ccnum = ccnum // 10
        digit2 = (ccnum % 10) * 2
        ccnum = ccnum // 10

        # check 2 digits in digit2
        if digit2 > 9:
            # add 2 digits
            digits += 1 + (digit2 % 10)
        else:
            digits = digits + digit2

    digits += digit1
    # check if valid ccnum
    if digits % 10 == 0:
        return True
    else:
        print("INVALID")
        sys.exit(0)


def companycheck(ccnum):
    ccnum = str(ccnum)
    # get the first two digits of ccnum
    ccinit2 = int((ccnum)[:2])
    # get the first digit of ccnum
    ccinit1 = int((ccnum)[:1])
    # check for company cc
    if len(ccnum) == 15 and (ccinit2 == 34 or ccinit2 == 37):
        return "AMEX"
    elif len(ccnum) == 16 and (ccinit2 >= 51 and ccinit2 <= 55):
        return "MASTERCARD"
    elif (len(ccnum) == 13 or len(ccnum) == 16) and (ccinit1 == 4):
        return "VISA"
    else:
        print("INVALID")
        sys.exit(0)

# 378282246310005


if __name__ == "__main__":
    main()