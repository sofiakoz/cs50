from cs50 import get_string
from sys import argv
import sys


def main():
    # TODO
    # check proper usage
    if len(argv) != 2:
        sys.exit("Usage: python bleep.py dictionary")

    # Store data
    infile = sys.argv[1]

    # load words from infile
    bannedwords = load(infile)

    # prompt user to provide message
    message = get_string("What message would you like to sensor?\n")

    # split message
    splitted = message.split(" ")

    # create string container for censored message
    censored = ""

    # iterate splitted user message
    for word in splitted:
        if word.lower() in bannedwords:
            censored += ("*" * len(word)) + " "
        else:
            censored += word + " "
    print(censored)


def load(infile):
    # open dictionary of banned words
    # banned words:
    words = set()

    # load words from text file
    bannedwords = open(infile, "r")
    for line in bannedwords:
        words.add(line.rstrip("\n"))
    bannedwords.close()
    return words


if __name__ == "__main__":
    main()
