# import modules
from cs50 import get_string
from sys import argv
import sys


def main():
    # TODO
    # correct usage
    if len(argv) != 2:
        sys.exit("Usage: python caesar.py k")

    # get the key
    key = argv[1]
    # check if key is alpha
    for k in key:
        if k.isalpha():
            continue
        else:
            sys.exit("Usage: python caesar.py k")

    # get the plaintext
    plaintext = get_string("plaintext: ")
    # print ciphertext
    print("ciphertext: ", end="")
    # encipher
    encipher(plaintext, key)
    print()

    # keyalpha = "hello"
    # print(keyalpha[0])


def encipher(text, k):
    # c = (p+k)%26
    keycursor = 0
    for char in text:
        # refresh key cursor
        if keycursor >= len(k):
            keycursor = 0

        # set key
        key = keycurr(k[keycursor])

        if char.isalpha():
            if char.isupper():
                c = ((ord(char) - 65) + key) % 26
                c = chr(c + 65)
                print(c, end="")
                keycursor += 1

            if char.islower():
                c = ((ord(char) - 97) + key) % 26
                c = chr(c + 97)
                print(c, end="")
                keycursor += 1
        else:
            print(char, end="")


# define current key generator
def keycurr(key):
    # if key is uppercase
    if key.isupper():
        return ord(key) - 65
    else:
        return ord(key) - 97


if __name__ == "__main__":
    main()