# function for splitting in sentence
from nltk.tokenize import sent_tokenize


def lines(a, b):
    """Return lines in both a and b"""

    # TODO
    # compares files based on number of lines in common

    # take in string inputs a,b
    # split each string into lines
    splitline1 = set(a.split("\n"))
    splitline2 = set(b.split("\n"))

    # compute a list of all lines that appear in both a and b
    # store similar lines
    simline = list(splitline1.intersection(splitline2))

    # return the list
    return simline


def sentences(a, b):
    """Return sentences in both a and b"""

    # TODO
    # compares files based on number of sentences in common

    # take in string inputs a,b
    # split each string into sentences
    splitsent1 = set(sent_tokenize(a))
    splitsent2 = set(sent_tokenize(b))

    # compute list of all sentences appearing in both a and b
    simsent = list(splitsent1.intersection(splitsent2))

    # return the list
    return simsent


def substrings(a, b, n):
    """Return substrings of length n in both a and b"""

    # TODO
    # compares files based on number of substrings of length in common

    # take in string inputs a, b and substring length n
    sub1 = []
    sub2 = []

    # split each string into all substrings of length n
    for i in range(len(a) - n + 1):
        sub1.append(a[i:i+n])

    for i in range(len(b) - n + 1):
        sub2.append(b[i:i+n])

    subset1 = set(sub1)
    subset2 = set(sub2)

    simsub = list(subset1.intersection(subset2))

    return simsub
